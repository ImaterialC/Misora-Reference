# Qwen (Assistant A) — Phase 1b Addendum Verdict: B4 / B5 / Game-Preview Skin
**Date:** 2026-11-22 · **Baseline of record:** 095242b (misora.py = 11,264 lines)
**Scope:** design/verdict memo only. No new source audit, no test runs this session.
**Companion document:** Qwen_Phase1b_CrossCheck_B1_B10.md (APPROVED FOR CROSS-CHECK).

## 0. Retraction
The HTML "game replica" prototype produced earlier in this session was an
out-of-scope hallucination. It is RETRACTED from the engineering record
(same discipline as NEW-1). It is not a spec, not a reference, and must
never be handed to the coding agent. The deliverable for this round is
this memo.

## 1. B4 — Mode naming: APPROVED / LOCK (user decision recorded)
User approved verbatim: **Dialogue Editor / Dialogue Preview / Story Editor /
Story Preview**.
- Two clean axes: scope (Dialogue = one box/page, Story = continuous) ×
  mode (Editor = raw NGUI editable, Preview = compiled read-only).
  The old "GAME VIEW" label conflated axes; the new names are self-describing.
- Header title must bind to the active mode exactly; Preview modes show a
  read-only badge; lower pane label stays **RAW SCRIPT (v2)** per sync brief.
- B4 is labeling + header sync only. No view behavior changes.
- Shortcut note: if Alt+1..4 is adopted, it must enter the MisoraShortcuts
  explicit whitelist, return "break", mask CapsLock, respect IME + modal
  grabs (Rule 12). Never intercept native Ctrl+C/V/X/A.
- Coordination: S8 (ribbon refactor) must not hardcode the old labels;
  naming lands in S8b on top of S8 infra.
**Acceptance:** all four exact strings appear on switch (button + shortcut);
read-only badge in both previews; RAW SCRIPT (v2) unchanged; zero functional
regression in the views themselves.
**Vote: APPROVE. Slice: S8b.**

## 2. B5 — Tooltips: APPROVED / LOCK (1-tier structured rich tooltip)
Concur with Gemini and with the prior Qwen cross-check. Extend the existing
`ToolTip` class (baseline def ~line 104; 350ms lifecycle already safe) —
do not invent a second system.
- Structure: **title (+shortcut chip) → description → italic example footer.**
  One ~350ms show timer, event-driven hide (<Leave>, button-press, focus-out,
  scroll, modal open). No auto-expansion stage.
- **2-stage timed tooltip: REJECTED.** Second timer + teardown race
  (F23-class after-job risk), destroy/grab interplay, marginal benefit.
  If ever pursued: one centralized TooltipManager, never per-widget timers.
- Copy registry: one central dict keyed by widget role so wording is
  consistent across ribbon/dock/drawer/MTL/import; strings out of hot paths.
- Example copy (the vision the user endorsed):
  • Lock 🔒 — "Translation Lock (Ctrl+L)" / "Protects this box from edits,
    replace-all, MTL apply, import. Caret stays; input rejected with toast;
    Cut becomes Copy." / ex: *Locked + type → "Box #7 is locked — unlock to edit".*
  • Gradient — "Vertical gradient" / "Two hex colors joined by HYPHEN;
    a comma renders as literal text." / ex: *[7B42BC-FF7DA7]text[-]*
  • Ruby — ex: *[rub:めいれい]願い[/rub]*
  • Paste (CSIF) — "Clipboard with @@ headers opens an explicit target
    chooser; nothing is applied silently."
  • Import preview — "Locked rows are skipped and reported; nothing applies
    before you confirm."
  • Pin — wording depends on open decision Q1 (both variants drafted).
- Tooltips never take focus; position clamped to screen; JP-IME unaffected.
**Acceptance:** every icon-only control has a structured tooltip; no orphan
Toplevel after destroy (open/close 50× + destroy dialog → zero leaks);
no tooltip during modal grab; manual Windows check.
**Vote: APPROVE. Slice: S8b.**

## 3. NEW IDEA — Game-faithful preview ("Priconne skin")
### 3a. Contained preview skin: APPROVE (S8b, rides with B1)
Trigger = the approved Preview modes themselves (B4). No separate "review"
button; no duplicate state. Preview ON → skin; OFF → editor theme restored
exactly, including the B1 Page-View focus/caret restore one-liner.
- **Surfaces:** Dialogue Preview = single game-style box (cream field, gold
  border, ink text, name plate, pink ▼ advance cue) over a contained scene
  backdrop. Story Preview = read-only list styled like the attached
  *Full Story Script Display* (blue speaker label, dotted separator,
  compiled text, optional portrait chip, voice-cue **badge**).
- **Code-first, assets optional (answers user's "asset atau tiruan kode"):**
  Stage 1 = tk.Frame/Canvas + Priconne palette + `best_contrast_fg()`;
  zero asset dependency, reads as Priconne immediately. Stage 2 = optional
  user-local asset pack (scene bg, pre-sliced nine-slice box, portraits),
  cached PhotoImage keyed by (size, theme), bounded LRU, `winfo_exists()`
  guards. Tk PhotoImage = PNG/GIF only; atlas must be pre-sliced.
  Provenance: game art stays a user-supplied local pack, NOT committed to
  the repo by default.
- **Fidelity boundary (answers user's "tidak 100 persen karena jeda"):**
  replicate layout + palette, NOT timing. Static read-only rendering.
  The digit fixture from the user's screenshot (66 chars × 3 lines) is
  adopted as the overflow acceptance fixture: overflow must be visibly
  handled (badge + paging/scroll), never silent truncation of data.
- **Invariants honored:** skin is pure view — reads compiled projection via
  core/ngui_tags.py; never assigns Box fields; records/journal/dirty
  untouched; preview stays state="disabled" + toast on edit attempt;
  rendered-length counters measure rendered text with the actual JP font
  stack (Yu Gothic UI / Meiryo fallback); no per-keystroke image work in
  the Continuous editor hot path (E-01/E-02 remain measure-first); no new
  after() without destroy() sweep; no module split (skin lives contained
  in misora.py; palette additions go through _apply_styles(), baseline
  ~2446 — coordinate with the independent B8 Treeview hotfix in the same
  function; B8 lands first).
**Acceptance:** skin ON/OFF round-trip restores editor exactly; compiled
text only; overflow visible; no edit/undo/dirty side effects; asset pack
absent → identical solid-frame fallback, no exceptions; studio themes
unaffected; manual Windows + JP-IME check.
**Vote: APPROVE as contained. Slice: S8b.**

### 3b. Full-app reskin ("semua tampilan seperti game"): DEFER (recommend)
Reasons: raw NGUI markup + dense small text lose legibility on cream/diamond
patterns; every widget class needs explicit style maps (B8 already proved
inheritance bites) → theme QA surface multiplies across dock/drawer/ribbon/
dialogs/MTL/import; paint cost per card; and the preview's product value is
*contrast* ("this is how it looks in-game") — wallpapering the editor destroys
that contrast. Zero-over-engineering discipline.
Offer: if the user still wants it, schedule a separate optional
"Priconne Cream" ttk theme AFTER 3a proves the palette helpers, with a
per-widget-class contrast audit, never default. **Vote: DEFER. User decision.**

### 3c. Explicitly OUT of the skin slice
Working game MENU (Auto/Speed/Skip/Hidden/Fast-forward/Bookmark/Log as game
features), typewriter playback, voice/audio playback, game pause timing,
per-card skin in Continuous EDITOR, restyling the live editor in place,
bundling copyrighted assets by default, new module split.

## 4. Slice placement / dependencies
B4 + B5 + contained skin → **S8b** (with B1/B2/B9/Pin). B8 micro-hotfix stays
independent (Q2 open). S8 must not cement old labels. **S0–S3 untouched;
S2 remains the next engineering prompt, still gated.**

## 5. Open decisions
Carried (unanswered): **Q1** Pin semantics (sticky-speaker fix vs same-speaker
jump feature) · **Q2** B8 in S4 vs standalone micro-hotfix (Qwen leans
standalone) · **Q3** wire vs remove dead `_update_gutter_cont()` (Qwen leans
remove).
New: **Q4** approve Stage-1 code-only → Stage-2 optional local asset pack?
(Qwen: yes) · **Q5** Story Preview depth = layout + optional portraits +
voice badge, no playback/typewriter/MENU? (Qwen: yes) · **Q6** full reskin:
defer as optional later theme (Qwen: defer) or commit now? (user).

## 6. Go / no-go for GPT relay
**Qwen verdict: B4 APPROVE-LOCK · B5 APPROVE-LOCK (1-tier rich) ·
contained game-skin APPROVE (S8b) · full reskin DEFER · playback OUT.**
Package to relay = prior B1–B10 cross-check + this addendum.
**READY TO RELAY.** GPT locks; user then approves S2 drafting per discipline.
Gemini's new B4/B5/skin note was not present in the relay; concurrence is
against the recorded brief — GPT arbitrates any delta.

## 7. Verification status
No new source reads or test runs performed this session. All file:line
anchors are carried from the recorded 095242b cross-check and MUST be
re-located by function name at current HEAD before any prompt quotes them.
No full-suite claim is made.