Berikut adalah terjemahannya ke dalam bahasa Indonesia. 

*(Catatan: Bagian teks bahasa Thailand dalam teks asli Anda adalah terjemahan dari bagian bahasa Inggris, sehingga saya menyajikannya dalam satu versi bahasa Indonesia yang padat dan jelas untuk menghindari pengulangan.)*

***

**Cara penggunaan** (Python 3 harus sudah terinstal. Pastikan untuk mencentang **"Add to PATH"** selama proses instalasi. UnityPy akan diinstal secara otomatis pada saat pertama kali dijalankan.)

1. Letakkan file `.unity3d` asli ke dalam folder `input`.
2. Klik dua kali `1_extract.bat` → File yang diekstrak akan muncul di folder `text`.
   - `story` = `.txt`
   - `movie` = `.json`
3. Buka file-file tersebut dan terjemahkan.
   - **story (`.txt`):** Hanya edit bagian teksnya saja. Jangan menghapus atau menambahkan baris struktural apa pun.
   - **movie (`.json`):** Hanya edit nilai `"text"` di setiap entri. Jumlah total entri harus tetap sama.
4. Klik dua kali `2_repack.bat` → File `.unity3d` yang telah diterjemahkan akan dibuat di folder `output`.

**Untuk Mac/Linux:** Gunakan perintah `python3 priconne_tool.py extract` / `repack` sebagai gantinya.