@echo off
cls
title Priconne Dataminer
cd /d "%~dp0"
:MENU
echo ==========================================
echo      PRICONNE - PYTHON SCRIPT LAUNCHER
echo ==========================================
echo.

rem Usage: run_dataminer.bat            -> interactive menu
rem        run_dataminer.bat textures   -> run one mode directly
py -3.12 dataminer.py %*

echo.
echo Script selesai atau berhenti karena error.
pause
goto MENU