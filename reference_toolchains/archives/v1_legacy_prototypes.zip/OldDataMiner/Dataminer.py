"""
Priconne Dataminer - single launcher script.

Run with no arguments for an interactive menu, or pass a mode directly:
    py -3.12 priconne_dataminer.py everything
    py -3.12 priconne_dataminer.py textures
    py -3.12 priconne_dataminer.py scripts
    py -3.12 priconne_dataminer.py movies
"""
import sys

from src import Dataminer

# --------------------------------------------------------------------------
# CONFIG - edit these lists as you discover more manifests / extensions
# --------------------------------------------------------------------------

# Every manifest you want "Everything" to cover. Open the downloaded manifest
# text files to find more names and add them here.
KNOWN_MANIFESTS = [
    "wac",
    "bg",
    "unit",
    "atlasngui",
    "icon",
    "banner",
    "gacha",
    "spine",
]

# These are NEVER included in "everything", "textures" or "scripts".
SKIP_MANIFESTS = {"sound", "movie"}

TEXTURE_EXTS = ["png", "jpg", "jpeg", "tga", "bmp", "webp"]
SCRIPT_EXTS = ["txt", "json", "csv", "lua", "bytes"]  # adjust to what your scripts use

MANIFESTS = [m for m in KNOWN_MANIFESTS if m not in SKIP_MANIFESTS]


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def ext_filter(exts):
    """Regex matching files by extension. Written as '.*...$' so it behaves the
    same whether Dataminer uses re.search or re.match."""
    return r"(?i).*\.(" + "|".join(exts) + r")$"


def run(dm, manifests, assetbundle_filter="", file_filter=""):
    """Run datamine over several manifests; one failure doesn't stop the rest."""
    for manifest in manifests:
        print(f"\n=== manifest: {manifest} | file filter: {file_filter or '(none)'} ===")
        try:
            dm.datamine(
                manifest_filter=manifest,
                assetbundle_filter=assetbundle_filter,
                file_filter=file_filter,
            )
        except Exception as e:  # keep going with the next manifest
            print(f"[!] {manifest} failed: {e!r}")


# --------------------------------------------------------------------------
# actions
# --------------------------------------------------------------------------

def mode_everything(dm):
    run(dm, MANIFESTS)


def mode_textures(dm):
    run(dm, MANIFESTS, file_filter=ext_filter(TEXTURE_EXTS))


def mode_scripts(dm):
    run(dm, MANIFESTS, file_filter=ext_filter(SCRIPT_EXTS))


def mode_movies(dm):
    # The movie manifest only has regular files, so no assetbundle filter.
    # Empty file filter = every movie file in that manifest.
    run(dm, ["movie"])


def mode_sound(dm):
    run(dm, ["sound"])


def mode_custom(dm):
    print("\nLeave a field empty for 'no filter'.")
    manifest = input("manifest_filter: ").strip()
    assetbundle = input("assetbundle_filter (regex): ").strip()
    file_ = input("file_filter (regex): ").strip()
    dm.datamine(
        manifest_filter=manifest,
        assetbundle_filter=assetbundle,
        file_filter=file_,
    )


def mode_unit_spine(dm):
    """Full SD skeleton workflow for one unit (same steps as sd_skel_example)."""
    raw = input("unit_id (e.g. 100111): ").strip()
    if not (raw.isdigit() and len(raw) == 6):
        print("Expected a 6-digit unit id.")
        return
    base = raw[:4]  # e.g. 1001 -> matches 1001xx (all uncap versions)
    unit_re = rf"{base}[0-9]{{2}}"

    dm.datamine(manifest_filter="spine", assetbundle_filter="000000", file_filter="cysp")
    dm.datamine(manifest_filter="spine", assetbundle_filter="common", file_filter="cysp")
    dm.datamine(manifest_filter="spine", assetbundle_filter=unit_re, file_filter=unit_re)
    dm.get_skel(int(raw))


MODES = {
    "everything": mode_everything,
    "textures": mode_textures,
    "scripts": mode_scripts,
    "movies": mode_movies,
    "sound": mode_sound,
    "custom": mode_custom,
    "spine": mode_unit_spine,
}

MENU = [
    ("everything", "Everything EXCEPT sound & movie"),
    ("textures", f"All textures ({', '.join(TEXTURE_EXTS)})"),
    ("scripts", f"All scripts ({', '.join(SCRIPT_EXTS)})"),
    ("movies", "All movies"),
    ("sound", "All sound (large!)"),
    ("spine", "Spine skeleton for one unit"),
    ("custom", "Custom filters"),
]


def menu(dm):
    while True:
        print("\n==========================================")
        print("        PRICONNE DATAMINER")
        print("==========================================")
        for i, (_, label) in enumerate(MENU, 1):
            print(f"  {i}. {label}")
        print("  0. Exit")
        choice = input("\nChoose: ").strip()
        if choice == "0":
            return
        if choice.isdigit() and 1 <= int(choice) <= len(MENU):
            MODES[MENU[int(choice) - 1][0]](dm)
            print("\nDone.")
        else:
            print("Invalid choice.")


def main():
    dm = Dataminer()
    # dm.disable_multiprocessing()  # uncomment if multiprocessing misbehaves

    if len(sys.argv) > 1:
        mode = sys.argv[1].lower()
        if mode not in MODES:
            print(f"Unknown mode '{mode}'. Options: {', '.join(MODES)}")
            return
        MODES[mode](dm)
    else:
        menu(dm)


if __name__ == "__main__":
    # keep all scripting in this scope to avoid bugs with multiprocessing
    main()