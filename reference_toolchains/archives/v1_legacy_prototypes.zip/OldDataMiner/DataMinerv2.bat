@echo off
cls
setlocal EnableExtensions EnableDelayedExpansion
title Priconne Python Script Launcher

cd /d "%~dp0"

:MENU
echo ==========================================
echo      PRICONNE - PYTHON SCRIPT LAUNCHER
echo ==========================================
echo.
echo Pilih script yang ingin dijalankan:
echo.

set "COUNT=0"
for %%F in (*.py) do (
    set /a COUNT+=1
    set "SCRIPT_!COUNT!=%%~nxF"
    echo   !COUNT!. %%~nxF
)

if !COUNT! EQU 0 (
    echo Tidak ada file .py di folder ini.
    echo.
    pause
    exit /b
)

echo.
echo   0. Keluar
echo.
set "PILIHAN="
set /p "PILIHAN=Masukkan nomor pilihan: "

if not defined PILIHAN goto MENU
if "!PILIHAN!"=="0" exit /b

set "TERPILIH="
for /L %%N in (1,1,!COUNT!) do (
    if "!PILIHAN!"=="%%N" set "TERPILIH=!SCRIPT_%%N!"
)

if not defined TERPILIH (
    echo.
    echo Pilihan tidak valid.
    pause
    goto MENU
)

echo.
echo Menjalankan !TERPILIH! dengan Python 3.12...
echo ==========================================
py -3.12 "!TERPILIH!"
echo ==========================================
echo.
echo Script selesai atau berhenti karena error.
pause
goto MENU
