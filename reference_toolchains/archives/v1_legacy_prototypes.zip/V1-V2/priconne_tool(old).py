#!/usr/bin/env python3
"""Priconne story / movie-subtitle bundle tool: extract -> translate -> repack.

  python priconne_tool.py extract <bundle.unity3d | folder> -o <out_folder>
  python priconne_tool.py repack  <bundle.unity3d | folder> <json | folder> -o <out>

Supports two bundle kinds (auto-detected):
  * story    : TextAsset "storydata_*"  (obfuscated command stream, see decode below)
  * subtitle : MonoBehaviour with recordList[{startTime,endTime,text}]  (plain)
               -> extracted as .json (story bundles are still .txt)

Story stream format (from starjet/derestage_storydecode):
    record = u16be command_id, then repeated (u32be length, bytes), ended by length 0
    arg bytes: invert every 3rd byte (i % 3 == 0) -> UTF-8 -> base64 -> UTF-8
Untranslated args are written back with their ORIGINAL bytes, so a repack with an
empty translation file reproduces the original stream byte-for-byte.
"""
import argparse
import base64
import json
import re
import struct
import sys
import warnings
from pathlib import Path

try:
    import UnityPy
except ImportError:
    import subprocess
    print("Installing UnityPy ...")
    r = subprocess.call([sys.executable, "-m", "pip", "install", "--only-binary=:all:", "UnityPy"])
    if r != 0:
        v = f"{sys.version_info.major}.{sys.version_info.minor}"
        raise SystemExit(
            f"\nติดตั้ง UnityPy ไม่สำเร็จบน Python {v}\n"
            "UnityPy ต้องใช้ Python 3.11 - 3.14 (Python เวอร์ชันใหม่กว่านั้นยังไม่มีไฟล์สำเร็จรูปของ lz4)\n"
            "-> ติดตั้ง Python 3.13 จาก python.org แล้วรันใหม่ (ติดตั้งคู่กับเวอร์ชันเดิมได้)")
    import UnityPy
import UnityPy.config

# The bundles have their Unity version stripped ("5.x.x 0.0.0"); any 2021.3.x works.
UnityPy.config.FALLBACK_UNITY_VERSION = "2021.3.20f1"
warnings.filterwarnings("ignore")

COMMANDS = [
    "title", "outline", "chara", "visible", "type", "face", "focus", "background",
    "print", "tag", "goto", "bgm", "touch", "choice", "vo", "wait",
    "in_L", "in_R", "out_L", "out_R", "fadein", "fadeout", "in_float", "out_float",
    "jump", "shake", "pop", "nod", "question_right", "question_left", "se", "black_out",
    "black_in", "white_out", "white_in", "transition", "situation", "color_fadein", "flash", "shake_text",
    "text_size", "shake_screen", "double", "flower_y", "flower_r", "concent", "find_l", "find_r",
    "laugh_l", "laugh_r", "chord_l", "chord_r", "sweat_l", "sweat_r", "question_l", "question_r",
    "angry", "drop_l", "drop_r", "live", "scale", "title_telop", "window_visible", "log",
    "novoice", "attract", "change", "fadeout_all",
]
JP_RE = re.compile(r"[぀-ヿ㐀-鿿ｦ-ﾟ]")


# --------------------------------------------------------------------------- story codec
def _invert3(b: bytes) -> bytes:
    o = bytearray(b)
    for i in range(0, len(o), 3):
        o[i] = ~o[i] & 0xFF
    return bytes(o)


def decode_arg(raw: bytes) -> str:
    return base64.b64decode(_invert3(raw)).decode("utf-8")


def encode_arg(text: str) -> bytes:
    return _invert3(base64.b64encode(text.encode("utf-8")))


def parse_story(data: bytes):
    """-> list of [cmd_id, [raw_arg_bytes, ...]]; keeps unknown ids; raises on truncation."""
    recs, pos, n = [], 0, len(data)
    while pos < n:
        if pos + 2 > n:
            raise ValueError(f"trailing bytes at {pos}")
        cid = struct.unpack_from(">H", data, pos)[0]
        pos += 2
        args = []
        while True:
            if pos + 4 > n:
                raise ValueError(f"truncated at {pos}")
            ln = struct.unpack_from(">I", data, pos)[0]
            pos += 4
            if ln == 0:
                break
            if pos + ln > n:
                raise ValueError(f"truncated arg at {pos}")
            args.append(data[pos:pos + ln])
            pos += ln
        recs.append([cid, args])
    return recs


def build_story(recs) -> bytes:
    out = bytearray()
    for cid, args in recs:
        out += struct.pack(">H", cid)
        for a in args:
            out += struct.pack(">I", len(a)) + a
        out += struct.pack(">I", 0)
    return bytes(out)


def cname(cid):
    return COMMANDS[cid] if cid < len(COMMANDS) else f"unknown_{cid}"


# --------------------------------------------------------------------------- bundle helpers
def load_bundle(path):
    env = UnityPy.load(str(path))
    story = sub = None
    for o in env.objects:
        if o.type.name == "TextAsset":
            d = o.read()
            if d.m_Name.startswith("storydata"):
                story = o
        elif o.type.name == "MonoBehaviour":
            try:
                t = o.read_typetree()
            except Exception:
                continue
            rl = t.get("recordList")
            if rl and isinstance(rl, list) and rl and "text" in rl[0]:
                sub = o
    if story is not None:
        return env, "story", story
    if sub is not None:
        return env, "subtitle", sub
    raise SystemExit(f"{path}: no storydata TextAsset or subtitle recordList found")


def story_bytes(obj) -> bytes:
    d = obj.read()
    s = d.m_Script
    return s.encode("utf-8", "surrogateescape") if isinstance(s, str) else bytes(s)


def save_bundle(env, out_path):
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    data = env.file.save(packer="original")
    Path(out_path).write_bytes(data)


# --------------------------------------------------------------------------- text format
# Story .txt  (same layout as derestage_storydecode):
#     <command>\r\n<arg>\r\n<arg>...\r\n<Category>\r\n\r\n
# Subtitle .json: [{"id": 1, "startTime": 0.0, "endTime": 2.5, "text": "..."}, ...]
#   (edit only "text"; keep the same number of entries. Old tab-separated .txt still works on repack.)
CATS = {"System", "Motion", "Effect"}
MOTION = set(range(16, 30)) | {60, 66}
EFFECT = set(range(43, 59))


def _category(cid):
    return "Motion" if cid in MOTION else "Effect" if cid in EFFECT else "System"


def story_to_text(recs) -> str:
    out = []
    for cid, args in recs:
        out.append(cname(cid) + "\r\n")
        out += [decode_arg(a) + "\r\n" for a in args]
        out.append(_category(cid) + "\r\n\r\n")
    return "".join(out)


def text_to_story(text: str, orig):
    """Parse edited text back to records, re-encoding only args that changed."""
    lines = text.replace("\r\n", "\n").split("\n")
    name2id = {n: i for i, n in enumerate(COMMANDS)}
    recs, k, idx = [], 0, 0
    while k < len(lines):
        if lines[k] == "" and k >= len(lines) - 1:
            break
        name = lines[k]; k += 1
        cid = name2id[name] if name in name2id else int(name.split("_")[1])
        args = []
        while not (lines[k] in CATS and (k + 1 >= len(lines) or lines[k + 1] == "")):
            args.append(lines[k]); k += 1
        k += 2                                    # category line + blank line
        old = orig[idx] if idx < len(orig) else None
        raw = []
        for j, a in enumerate(args):
            if old and old[0] == cid and j < len(old[1]) and decode_arg(old[1][j]) == a:
                raw.append(old[1][j])             # unchanged -> original bytes
            else:
                raw.append(encode_arg(a))
        recs.append([cid, raw]); idx += 1
    return recs


def sub_to_json(rl) -> str:
    items = [{"id": i + 1, "startTime": r["startTime"], "endTime": r["endTime"], "text": r["text"]}
             for i, r in enumerate(rl)]
    return json.dumps(items, ensure_ascii=False, indent=2) + "\n"


def json_to_sub(text, rl):
    data = json.loads(text)
    if isinstance(data, dict):                        # also accept {"subtitles": [...]} / {"recordList": [...]}
        data = data.get("subtitles") or data.get("recordList") or data.get("records")
    if not isinstance(data, list):
        raise SystemExit("subtitle json must be a list of {startTime,endTime,text}")
    if len(data) != len(rl):
        raise SystemExit(f"subtitle count changed: {len(data)} entries vs {len(rl)} in bundle")
    for r, d in zip(rl, data):
        r["startTime"] = float(d.get("startTime", r["startTime"]))
        r["endTime"] = float(d.get("endTime", r["endTime"]))
        r["text"] = str(d["text"])
    return rl


def sub_to_text(rl) -> str:                           # legacy tab-separated format
    return "".join(f"{r['startTime']!r}\t{r['endTime']!r}\t{r['text']}\r\n" for r in rl)


def text_to_sub(text, rl):
    rows = [l for l in text.replace("\r\n", "\n").split("\n") if l != ""]
    if len(rows) != len(rl):
        raise SystemExit(f"subtitle count changed: {len(rows)} lines vs {len(rl)} in bundle")
    for r, row in zip(rl, rows):
        st, en, tx = row.split("\t", 2)
        r["startTime"], r["endTime"], r["text"] = float(st), float(en), tx
    return rl


# --------------------------------------------------------------------------- extract
def extract_one(src: Path, outdir: Path):
    env, kind, obj = load_bundle(src)
    outdir.mkdir(parents=True, exist_ok=True)
    if kind == "story":
        recs = parse_story(story_bytes(obj))
        text = story_to_text(recs)
        if build_story(text_to_story(text, recs)) != story_bytes(obj):   # safety net
            raise SystemExit(f"{src.name}: text round-trip is not lossless; aborting")
    else:
        rl = obj.read_typetree()["recordList"]
        text = sub_to_json(rl)
    p = outdir / f"{src.stem}{'.txt' if kind == 'story' else '.json'}"
    p.write_text(text, encoding="utf-8", newline="")
    print(f"[extract] {src.name}: {kind} -> {p}")


# --------------------------------------------------------------------------- repack
def out_name(src: Path) -> str:
    """72093f93-5150427.unity3d -> storydata_5150427.unity3d
       2ace174f-movie_221509981.unity3d -> storydata_movie_221509981.unity3d"""
    base = src.stem.split("-", 1)[-1]               # drop the hash before the first '-'
    if not base.startswith("storydata_"):
        base = "storydata_" + base
    return base + src.suffix


def repack_one(src: Path, tl: Path, out: Path):
    text = tl.read_text(encoding="utf-8-sig")
    env, kind, obj = load_bundle(src)
    if kind == "story":
        if tl.suffix.lower() == ".json":
            raise SystemExit(f"{src.name}: story bundles use .txt, not {tl.name}")
        recs = text_to_story(text, parse_story(story_bytes(obj)))
        d = obj.read()
        d.m_Script = build_story(recs).decode("utf-8", "surrogateescape")
        d.save()
    else:
        t = obj.read_typetree()
        conv = json_to_sub if tl.suffix.lower() == ".json" else text_to_sub
        t["recordList"] = conv(text, t["recordList"])
        obj.save_typetree(t)
    save_bundle(env, out)
    print(f"[repack] {src.name} <- {tl.name} -> {out}")


# --------------------------------------------------------------------------- cli
def main():
    ap = argparse.ArgumentParser(
        description="Run with no arguments for the default folders: input/ -> text/ -> output/")
    sp = ap.add_subparsers(dest="cmd")
    e = sp.add_parser("extract", help="input/*.unity3d -> text/*.txt (story) or *.json (movie)")
    e.add_argument("src", nargs="?", default="input"); e.add_argument("-o", "--out", default="text")
    r = sp.add_parser("repack", help="input/*.unity3d + text/*.txt|json -> output/*.unity3d")
    r.add_argument("src", nargs="?", default="input"); r.add_argument("tl", nargs="?", default="text")
    r.add_argument("-o", "--out", default="output")
    a = ap.parse_args()

    if a.cmd is None:                                   # double-click / no-argument mode
        print("1 = extract (input -> text)\n2 = repack  (input + text -> output)")
        c = input("Choose 1 or 2: ").strip()
        a = ap.parse_args(["extract"] if c == "1" else ["repack"])

    src, out = Path(a.src), Path(a.out)
    if not src.exists():
        src.mkdir(parents=True)
        raise SystemExit(f"Created folder '{src}'. Put your .unity3d files in it and run again.")
    files = sorted(src.glob("*.unity3d")) if src.is_dir() else [src]
    if not files:
        raise SystemExit(f"No .unity3d files in '{src}'.")
    if a.cmd == "extract":
        for f in files:
            extract_one(f, out)
        print(f"\nDone. Translate the .txt files in '{out}', then run repack.")
    else:
        tl = Path(a.tl)
        n = 0
        for f in files:
            if tl.is_dir():                                # subtitle -> .json first, else .txt
                tlf = next((tl / f"{f.stem}{e}" for e in (".json", ".txt") if (tl / f"{f.stem}{e}").exists()), None)
            else:
                tlf = tl if tl.exists() else None
            if tlf is None:
                print(f"[skip] no .json/.txt for {f.name}"); continue
            repack_one(f, tlf, (out / out_name(f)) if (src.is_dir() or out.is_dir()) else out); n += 1
        print(f"\nDone. {n} file(s) written to '{out}'.")


if __name__ == "__main__":
    main()
