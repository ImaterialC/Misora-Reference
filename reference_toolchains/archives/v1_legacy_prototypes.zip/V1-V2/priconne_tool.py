#!/usr/bin/env python3
"""Priconne story / movie-subtitle bundle tool: extract -> translate -> repack.

Run with no arguments for the interactive menu, or:
  python priconne_tool.py extract [-i input] [-t text] [-r] [--flat] [--extract-name PATTERN]
  python priconne_tool.py repack  [-i input] [-t text] [-o output] [-r] [--flat]
                                  [--extract-name PATTERN] [--repack-name PATTERN]

Bundle kinds (auto-detected):
  * story    : TextAsset "storydata_*"  (obfuscated command stream)  -> .txt
  * subtitle : MonoBehaviour with recordList[{startTime,endTime,text}] -> .json

A file that can't be read or parsed is reported and SKIPPED; the run continues
with the next file and prints a summary at the end.

Story stream format (from starjet/derestage_storydecode):
    record = u16be command_id, then repeated (u32be length, bytes), ended by length 0
    arg bytes: invert every 3rd byte (i % 3 == 0) -> UTF-8 -> base64 -> UTF-8
Untranslated args are written back with their ORIGINAL bytes, so a repack with an
unchanged text file reproduces the original stream byte-for-byte.
"""
import argparse
import base64
import json
import re
import struct
import sys
import warnings
from collections import Counter
from pathlib import Path

try:
    import UnityPy
except ImportError:
    import subprocess
    print("Installing UnityPy ...")
    r = subprocess.call([sys.executable, "-m", "pip", "install", "--only-binary=:all:", "UnityPy"])
    if r != 0:
        v = f"{sys.version_info.major}.{sys.version_info.minor}"
        raise SystemExit(
            f"\nCould not install UnityPy on Python {v}.\n"
            "UnityPy needs Python 3.11 - 3.14 (newer versions have no prebuilt lz4 wheel).\n"
            "-> Install Python 3.13 from python.org (side by side with your current one) and run again.")
    import UnityPy
import UnityPy.config

# The bundles have their Unity version stripped ("5.x.x 0.0.0"); any 2021.3.x works.
UnityPy.config.FALLBACK_UNITY_VERSION = "2021.3.20f1"
warnings.filterwarnings("ignore")

COMMANDS = [
    "title", "outline", "chara", "visible", "type", "face", "focus", "background",
    "print", "tag", "goto", "bgm", "touch", "choice", "vo", "wait",
    "in_L", "in_R", "out_L", "out_R", "fadein", "fadeout", "in_float", "out_float",
    "jump", "shake", "pop", "nod", "question_right", "question_left", "se", "black_out",
    "black_in", "white_out", "white_in", "transition", "situation", "color_fadein", "flash", "shake_text",
    "text_size", "shake_screen", "double", "flower_y", "flower_r", "concent", "find_l", "find_r",
    "laugh_l", "laugh_r", "chord_l", "chord_r", "sweat_l", "sweat_r", "question_l", "question_r",
    "angry", "drop_l", "drop_r", "live", "scale", "title_telop", "window_visible", "log",
    "novoice", "attract", "change", "fadeout_all",
]


class ToolError(Exception):
    """A problem with one file (reported as ERR, run continues)."""


class NotSupported(ToolError):
    """File is fine but not something we handle / nothing to do (reported as skip)."""


# --------------------------------------------------------------------------- story codec
def _invert3(b: bytes) -> bytes:
    o = bytearray(b)
    for i in range(0, len(o), 3):
        o[i] = ~o[i] & 0xFF
    return bytes(o)


def decode_arg(raw: bytes) -> str:
    return base64.b64decode(_invert3(raw)).decode("utf-8")


def encode_arg(text: str) -> bytes:
    return _invert3(base64.b64encode(text.encode("utf-8")))


def parse_story(data: bytes):
    """-> list of [cmd_id, [raw_arg_bytes, ...]]; keeps unknown ids; raises on truncation."""
    recs, pos, n = [], 0, len(data)
    while pos < n:
        if pos + 2 > n:
            raise ToolError(f"story data: trailing bytes at {pos}")
        cid = struct.unpack_from(">H", data, pos)[0]
        pos += 2
        args = []
        while True:
            if pos + 4 > n:
                raise ToolError(f"story data: truncated at {pos}")
            ln = struct.unpack_from(">I", data, pos)[0]
            pos += 4
            if ln == 0:
                break
            if pos + ln > n:
                raise ToolError(f"story data: truncated arg at {pos}")
            args.append(data[pos:pos + ln])
            pos += ln
        recs.append([cid, args])
    return recs


def build_story(recs) -> bytes:
    out = bytearray()
    for cid, args in recs:
        out += struct.pack(">H", cid)
        for a in args:
            out += struct.pack(">I", len(a)) + a
        out += struct.pack(">I", 0)
    return bytes(out)


def cname(cid):
    return COMMANDS[cid] if cid < len(COMMANDS) else f"unknown_{cid}"


# --------------------------------------------------------------------------- bundle helpers
def load_bundle(path):
    try:
        env = UnityPy.load(str(path))
    except Exception as e:
        raise ToolError(f"cannot open as Unity bundle ({e.__class__.__name__}: {e})")
    story = sub = None
    for o in env.objects:
        try:
            if o.type.name == "TextAsset":
                d = o.read()
                if d.m_Name.startswith("storydata"):
                    story = o
            elif o.type.name == "MonoBehaviour":
                t = o.read_typetree()
                rl = t.get("recordList")
                if rl and isinstance(rl, list) and "text" in rl[0]:
                    sub = o
        except Exception:
            continue
    if story is not None:
        return env, "story", story
    if sub is not None:
        return env, "subtitle", sub
    raise NotSupported("no storydata TextAsset or subtitle recordList in this bundle")


def story_bytes(obj) -> bytes:
    s = obj.read().m_Script
    return s.encode("utf-8", "surrogateescape") if isinstance(s, str) else bytes(s)


def save_bundle(env, out_path: Path):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(env.file.save(packer="original"))


# --------------------------------------------------------------------------- text format
# Story .txt:  <command>\r\n<arg>\r\n<arg>...\r\n<Category>\r\n\r\n
# Subtitle .json: [{"id": 1, "startTime": 0.0, "endTime": 2.5, "text": "..."}, ...]
#   (edit only "text"; keep the same number of entries. Old tab-separated .txt still works on repack.)
CATS = {"System", "Motion", "Effect"}
MOTION = set(range(16, 30)) | {60, 66}
EFFECT = set(range(43, 59))


def _category(cid):
    return "Motion" if cid in MOTION else "Effect" if cid in EFFECT else "System"


def story_to_text(recs) -> str:
    out = []
    for cid, args in recs:
        out.append(cname(cid) + "\r\n")
        out += [decode_arg(a) + "\r\n" for a in args]
        out.append(_category(cid) + "\r\n\r\n")
    return "".join(out)


def text_to_story(text: str, orig):
    """Parse edited text back to records, re-encoding only args that changed."""
    lines = text.replace("\r\n", "\n").split("\n")
    name2id = {n: i for i, n in enumerate(COMMANDS)}
    recs, k, idx = [], 0, 0
    try:
        while k < len(lines):
            if lines[k] == "" and k >= len(lines) - 1:
                break
            name = lines[k]
            k += 1
            cid = name2id[name] if name in name2id else int(name.split("_")[1])
            args = []
            while not (lines[k] in CATS and (k + 1 >= len(lines) or lines[k + 1] == "")):
                args.append(lines[k])
                k += 1
            k += 2                                    # category line + blank line
            old = orig[idx] if idx < len(orig) else None
            raw = []
            for j, a in enumerate(args):
                if old and old[0] == cid and j < len(old[1]) and decode_arg(old[1][j]) == a:
                    raw.append(old[1][j])             # unchanged -> original bytes
                else:
                    raw.append(encode_arg(a))
            recs.append([cid, raw])
            idx += 1
    except (KeyError, ValueError, IndexError) as e:
        raise ToolError(f"text format error near line {k + 1} (command/category layout broken): {e!r}")
    return recs


def sub_to_json(rl) -> str:
    items = [{"id": i + 1, "startTime": r["startTime"], "endTime": r["endTime"], "text": r["text"]}
             for i, r in enumerate(rl)]
    return json.dumps(items, ensure_ascii=False, indent=2) + "\n"


def json_to_sub(text, rl):
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise ToolError(f"invalid JSON: {e}")
    if isinstance(data, dict):                        # also accept {"subtitles": [...]} / {"recordList": [...]}
        data = data.get("subtitles") or data.get("recordList") or data.get("records")
    if not isinstance(data, list):
        raise ToolError("subtitle json must be a list of {startTime,endTime,text}")
    if len(data) != len(rl):
        raise ToolError(f"subtitle count changed: {len(data)} entries vs {len(rl)} in bundle")
    try:
        for r, d in zip(rl, data):
            r["startTime"] = float(d.get("startTime", r["startTime"]))
            r["endTime"] = float(d.get("endTime", r["endTime"]))
            r["text"] = str(d["text"])
    except (KeyError, TypeError, ValueError) as e:
        raise ToolError(f"bad subtitle entry: {e!r}")
    return rl


def sub_to_text(rl) -> str:                           # legacy tab-separated format
    return "".join(f"{r['startTime']!r}\t{r['endTime']!r}\t{r['text']}\r\n" for r in rl)


def text_to_sub(text, rl):
    rows = [l for l in text.replace("\r\n", "\n").split("\n") if l != ""]
    if len(rows) != len(rl):
        raise ToolError(f"subtitle count changed: {len(rows)} lines vs {len(rl)} in bundle")
    try:
        for r, row in zip(rl, rows):
            st, en, tx = row.split("\t", 2)
            r["startTime"], r["endTime"], r["text"] = float(st), float(en), tx
    except ValueError as e:
        raise ToolError(f"bad tab-separated subtitle line: {e!r}")
    return rl


# --------------------------------------------------------------------------- naming / placeholders
LEGEND = """\
Rename placeholders (use in the Extract / Repack name patterns):
  {name}     original file name without extension      72093f93-5150427
  {hash}     part before the first '-'                 72093f93   (empty if no '-')
  {id}       part after the first '-'                  5150427    (whole name if no '-')
  {default}  classic repack name                       storydata_5150427
  {folder}   name of the folder the file is in         chapter1
  {path}     subfolder path under the scan root,       chapter1_part2
             joined with '_'                           (empty for files in the root)
  {kind}     story / subtitle
  {index}    running number in this run (1,2,3...)     {index:04d} -> 0001
  {ext}      original extension without the dot        unity3d
The file extension is added automatically (.txt/.json on extract, .unity3d on repack).
Characters Windows doesn't allow in file names are replaced with '_'.
Examples:  {folder}_{name}    {kind}_{id}    {index:04d}_{default}
Note: repack finds the translation file using the EXTRACT pattern (then falls back to
the original name), so keep the Extract pattern the same as when you extracted."""

SAMPLE = dict(name="a-b", ext="unity3d", folder="f", path="p", hash="a", id="b",
              kind="story", index=1, default="storydata_b")


def check_pattern(pattern: str) -> bool:
    try:
        pattern.format(**SAMPLE)
        return True
    except (KeyError, IndexError, ValueError) as e:
        print(f"  Invalid pattern ({e!r}). Unknown placeholder or broken braces. See legend (option 7).")
        return False


def make_name(pattern, src: Path, root: Path, index: int, kind: str) -> str:
    stem = src.stem
    h, sep, rest = stem.partition("-")
    id_ = rest if sep else stem
    default = id_ if id_.startswith("storydata_") else "storydata_" + id_
    try:
        path = "_".join(src.parent.relative_to(root).parts)
    except ValueError:
        path = ""
    name = pattern.format(name=stem, ext=src.suffix.lstrip("."), folder=src.parent.name, path=path,
                          hash=h if sep else "", id=id_, kind=kind, index=index, default=default)
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return name or stem


# --------------------------------------------------------------------------- scanning / paths
def scan(src: Path, recursive: bool, exclude):
    """-> (root, files). Prints where it is scanning and how many files per folder."""
    src = src.resolve()
    if not src.exists():
        src.mkdir(parents=True)
        print(f"Created folder '{src}'. Put your .unity3d files in it and run again.")
        return src, []
    if src.is_file():
        print(f"Scanning: single file {src}")
        return src.parent, [src]
    excl = [e.resolve() for e in exclude]
    it = src.rglob("*") if recursive else src.iterdir()
    files = sorted(p for p in it
                   if p.is_file() and p.suffix.lower() == ".unity3d"
                   and not any(e in p.parents for e in excl))
    print(f"Scanning: {src}")
    print(f"  Subfolders: {'ON' if recursive else 'OFF'}  |  found {len(files)} .unity3d file(s)")
    for folder, n in sorted(Counter(str(p.parent.relative_to(src)) for p in files).items()):
        print(f"    {'(root)' if folder == '.' else folder}: {n}")
    if not files:
        print("  Nothing to do." + ("" if recursive else "  (Subfolders are OFF - toggle with option 3.)"))
    return src, files


def unique_path(p: Path, used: set) -> Path:
    q, n = p, 2
    while q in used:
        q = p.with_name(f"{p.stem}_{n}{p.suffix}")
        n += 1
    used.add(q)
    return q


def rel_sub(f: Path, root: Path, mirror: bool) -> Path:
    return f.parent.relative_to(root) if mirror else Path()


class Stats:
    def __init__(self):
        self.ok = 0
        self.skipped = []
        self.failed = []

    def run(self, tag, fn):
        try:
            msg = fn()
            self.ok += 1
            print(f"  [ok]   {tag}  {msg or ''}")
        except NotSupported as e:
            self.skipped.append((tag, str(e)))
            print(f"  [skip] {tag}: {e}")
        except ToolError as e:
            self.failed.append((tag, str(e)))
            print(f"  [ERR]  {tag}: {e}")
        except Exception as e:                        # never let one file stop the batch
            self.failed.append((tag, repr(e)))
            print(f"  [ERR]  {tag}: {e!r}")

    def report(self, log_path: Path):
        print(f"\nSummary: {self.ok} ok, {len(self.skipped)} skipped, {len(self.failed)} failed.")
        lines = [f"SKIP {t}: {m}" for t, m in self.skipped] + [f"ERR  {t}: {m}" for t, m in self.failed]
        if lines:
            log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            print(f"Details of skipped/failed files saved to: {log_path}")


# --------------------------------------------------------------------------- extract / repack
LOG_PATH = Path(__file__).with_name("priconne_tool.log")


def run_extract(cfg):
    out = Path(cfg["text"]).resolve()
    root, files = scan(Path(cfg["input"]), cfg["recursive"], [out, Path(cfg["output"])])
    print(f"Extracting to: {out}  (mirror subfolders: {'ON' if cfg['mirror'] else 'OFF'})\n")
    st, used = Stats(), set()
    for i, f in enumerate(files, 1):
        def job():
            _, kind, obj = load_bundle(f)
            if kind == "story":
                recs = parse_story(story_bytes(obj))
                text = story_to_text(recs)
                if build_story(text_to_story(text, recs)) != story_bytes(obj):   # safety net
                    raise ToolError("text round-trip is not lossless; not written")
            else:
                text = sub_to_json(obj.read_typetree()["recordList"])
            stem = make_name(cfg["extract_name"], f, root, i, kind)
            p = unique_path(out / rel_sub(f, root, cfg["mirror"]) / (stem + (".txt" if kind == "story" else ".json")), used)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(text, encoding="utf-8", newline="")
            return f"{kind} -> {p.relative_to(out)}"
        st.run(str(f.relative_to(root)), job)
    st.report(LOG_PATH)
    print(f"Translate the files in '{out}', then run repack.")


def find_translation(tl_root: Path, f: Path, root: Path, kind: str, cfg, index: int):
    sub = rel_sub(f, root, cfg["mirror"])
    stems = [make_name(cfg["extract_name"], f, root, index, kind), f.stem]
    exts = [".txt"] if kind == "story" else [".json", ".txt"]
    dirs = [tl_root / sub] + ([tl_root] if sub != Path() else [])
    for d in dirs:
        for s in stems:
            for e in exts:
                if (d / (s + e)).exists():
                    return d / (s + e)
    return None


def run_repack(cfg):
    tl_root = Path(cfg["text"]).resolve()
    out = Path(cfg["output"]).resolve()
    root, files = scan(Path(cfg["input"]), cfg["recursive"], [tl_root, out])
    print(f"Translations from: {tl_root}\nWriting to: {out}  (mirror subfolders: {'ON' if cfg['mirror'] else 'OFF'})\n")
    st, used = Stats(), set()
    for i, f in enumerate(files, 1):
        def job():
            env, kind, obj = load_bundle(f)
            tl = find_translation(tl_root, f, root, kind, cfg, i)
            if tl is None:
                raise NotSupported(f"no translation file ({'.txt' if kind == 'story' else '.json/.txt'}) found")
            text = tl.read_text(encoding="utf-8-sig")
            if kind == "story":
                if tl.suffix.lower() == ".json":
                    raise ToolError(f"story bundles use .txt, not {tl.name}")
                recs = text_to_story(text, parse_story(story_bytes(obj)))
                d = obj.read()
                d.m_Script = build_story(recs).decode("utf-8", "surrogateescape")
                d.save()
            else:
                t = obj.read_typetree()
                conv = json_to_sub if tl.suffix.lower() == ".json" else text_to_sub
                t["recordList"] = conv(text, t["recordList"])
                obj.save_typetree(t)
            stem = make_name(cfg["repack_name"], f, root, i, kind)
            p = unique_path(out / rel_sub(f, root, cfg["mirror"]) / (stem + f.suffix), used)
            save_bundle(env, p)
            return f"<- {tl.name} -> {p.relative_to(out)}"
        st.run(str(f.relative_to(root)), job)
    st.report(LOG_PATH)


# --------------------------------------------------------------------------- settings / menu
SETTINGS_PATH = Path(__file__).with_name("priconne_tool_settings.json")
DEFAULTS = dict(input="input", text="text", output="output", recursive=False, mirror=True,
                extract_name="{name}", repack_name="{default}")


def load_settings():
    cfg = dict(DEFAULTS)
    try:
        cfg.update({k: v for k, v in json.loads(SETTINGS_PATH.read_text(encoding="utf-8")).items() if k in DEFAULTS})
    except Exception:
        pass
    return cfg


def save_settings(cfg):
    try:
        SETTINGS_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except OSError:
        pass


def ask(label, current):
    v = input(f"  {label} [{current}] (Enter = keep): ").strip().strip('"')
    return v or current


def menu(cfg):
    while True:
        onoff = lambda b: "ON" if b else "OFF"
        print("\n==========================================")
        print("          PRICONNE STORY TOOL")
        print("==========================================")
        print(f" Input  folder : {Path(cfg['input']).resolve()}")
        print(f" Text   folder : {Path(cfg['text']).resolve()}")
        print(f" Output folder : {Path(cfg['output']).resolve()}")
        print(f" Scan subfolders: {onoff(cfg['recursive'])}   Mirror subfolders in text/output: {onoff(cfg['mirror'])}")
        print(f" Extract name  : {cfg['extract_name']}")
        print(f" Repack name   : {cfg['repack_name']}")
        print("\n 1. Extract  (input -> text)")
        print(" 2. Repack   (input + text -> output)")
        print(" 3. Toggle scan subfolders")
        print(" 4. Toggle mirror subfolder structure")
        print(" 5. Set folders")
        print(" 6. Set rename patterns")
        print(" 7. Show placeholder legend")
        print(" 0. Exit")
        c = input("\nChoose: ").strip()
        if c == "0":
            return
        elif c == "1":
            run_extract(cfg)
        elif c == "2":
            run_repack(cfg)
        elif c == "3":
            cfg["recursive"] = not cfg["recursive"]
        elif c == "4":
            cfg["mirror"] = not cfg["mirror"]
        elif c == "5":
            cfg["input"] = ask("Input folder (or one .unity3d file)", cfg["input"])
            cfg["text"] = ask("Text folder", cfg["text"])
            cfg["output"] = ask("Output folder", cfg["output"])
        elif c == "6":
            print("\n" + LEGEND + "\n")
            for key, label in (("extract_name", "Extract name pattern"), ("repack_name", "Repack name pattern")):
                v = ask(label, cfg[key])
                if check_pattern(v):
                    cfg[key] = v
        elif c == "7":
            print("\n" + LEGEND)
        else:
            print("Invalid choice.")
            continue
        save_settings(cfg)


def main():
    ap = argparse.ArgumentParser(description="Run with no arguments for the interactive menu.")
    ap.add_argument("mode", nargs="?", choices=["extract", "repack"])
    ap.add_argument("-i", "--input")
    ap.add_argument("-t", "--text")
    ap.add_argument("-o", "--output")
    ap.add_argument("-r", "--recursive", action="store_true", help="scan subfolders")
    ap.add_argument("--flat", action="store_true", help="don't mirror subfolders in text/output")
    ap.add_argument("--extract-name")
    ap.add_argument("--repack-name")
    a = ap.parse_args()

    cfg = load_settings()
    if a.mode is None:
        menu(cfg)
        return
    for key in ("input", "text", "output", "extract_name", "repack_name"):
        if getattr(a, key) is not None:
            cfg[key] = getattr(a, key)
    if a.recursive:
        cfg["recursive"] = True
    if a.flat:
        cfg["mirror"] = False
    if not (check_pattern(cfg["extract_name"]) and check_pattern(cfg["repack_name"])):
        raise SystemExit(1)
    (run_extract if a.mode == "extract" else run_repack)(cfg)


if __name__ == "__main__":
    main()
